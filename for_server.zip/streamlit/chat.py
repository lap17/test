import streamlit as st
import json
import requests


st.set_page_config(
    page_title = "Chat",
    layout = 'wide',
    page_icon = "🛢️", 
    initial_sidebar_state = "auto", 
)

list_params = ["txt", "user_txt"]
for key in list_params:
    if key not in st.session_state:
        st.session_state[key] = ''

if "messages" not in st.session_state:
    st.session_state.messages = []

def replace_text_base(prompt):
    st.session_state.user_txt = st.session_state.txt
    st.session_state.txt = prompt.replace(st.session_state.txt, "")


def chat():
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    place_user_role = st.empty()
    place_assistant = st.empty()
    place_text_area = st.empty()
    col1, col2, col3, col4 = st.columns([1,1,1,3])
    with place_text_area:
        prompt = st.text_area('',key="txt")
    if col1.button('Отправить',on_click=replace_text_base, args=[prompt]):
        query = st.session_state.user_txt
        with place_user_role:
            st.chat_message("user").markdown(query)
        history = st.session_state.messages.append({"role": "user", "content": query})
        inputs = {'file_name': query}
        r = requests.post(url = "http://web:8000/chat/", json = json.dumps(inputs))
        response = r.json()
        response = "[скачать](%s)" % response
        with place_assistant:
            message_assyst = st.chat_message("assistant")
            message_assyst.markdown(response)
            st.session_state.messages.append({"role": "assistant", "content": response})

chat()