from fastapi import FastAPI, Request
import logging
import boto3
import os
import json


BUCKET_NAME_FOR_URL_FILES = os.environ['BUCKET_NAME_FOR_URL_FILES']
MINIO_HOST = os.environ['MINIO_HOST'] 
MINIO_ACCESS_KEY_ID = os.environ['MINIO_ACCESS_KEY_ID'] 
MINIO_SECRET_ACCESS_KEY = os.environ['MINIO_SECRET_ACCESS_KEY']
#EXTERNAL_URL = os.environ['EXTERNAL_URL']

logger = logging.getLogger(__name__)
app = FastAPI()

def create_presigned_url(object_name, expiration=60000):
    s3_client = boto3.client(
        's3', 
        endpoint_url = "http://127.0.0.1/",
        aws_access_key_id=MINIO_ACCESS_KEY_ID,
        aws_secret_access_key=MINIO_SECRET_ACCESS_KEY, 
    )
    response = s3_client.generate_presigned_url(
        'get_object',
        Params={'Bucket': BUCKET_NAME_FOR_URL_FILES,
        'Key': object_name},
        ExpiresIn=expiration
    )
    response = response.replace("https://127.0.0.1","").replace("http://127.0.0.1","").replace(":9000","").replace(":9090","")
    return response


# чат в виде запроса по документу
@app.post("/chat/")
async def chat_with_DB(request: Request):                                  
    r = await request.json()
    r = json.loads(r)
    file_name = r.get("file_name", None)
    return create_presigned_url(file_name, expiration=60000)
